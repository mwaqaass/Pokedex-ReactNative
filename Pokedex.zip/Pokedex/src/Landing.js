import React from 'react';
import {View,Text,Button,ImageBackground,Platform} from 'react-native';

class Landing extends React.Component{
    render(){
      return(
          <View>
            <ImageBackground source={require('../assets/icons/start1.jpg')} style={{width:'100%',height:'100%'}} >
              <View style={styles.search}>
                <Text style={styles.titleStyle}>Welcome to Pokedex</Text>
                <View style={styles.abc}>
                  <Button
                    title="Start Searching"
                    color="red"
                    block={true}
                    onPress={()=>this.props.switchScreen("search")}
                    >
                  </Button>
                </View>
              </View>
            </ImageBackground>
          </View>
      )
    }
}

const styles = {
  search:{
    flex: 1,
    flexDirection:'column',
    justifyContent: 'center',
    alignItems:'center'
  },
  titleStyle:{
    color:'#F8D210',
    fontSize:30
  },
  abc:{
    marginTop:10,
  },
}

export default Landing;